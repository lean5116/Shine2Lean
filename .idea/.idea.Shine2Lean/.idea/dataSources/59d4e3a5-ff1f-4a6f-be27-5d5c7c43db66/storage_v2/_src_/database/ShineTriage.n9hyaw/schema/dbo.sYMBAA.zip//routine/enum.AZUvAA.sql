
create FUNCTION [dbo].[enum]
(
	-- Add the parameters for the function here
	@type varchar(100),
	@value bigint
)
RETURNS varchar(500)
AS
BEGIN
declare @interval varchar(500)
set @interval=''

if @type='time_interval'
	begin
		if @value = 34359738367
			return '全天'
		if @value | 1108378657 = @value
			set @interval=@interval+'早晨,'
		else
		begin
			if @value | 1 = @value set @interval=@interval+'一早晨,'
			if  @value | 32 = @value set @interval=@interval+'二早晨,'
			if  @value | 1024 = @value set @interval=@interval+'三早晨,'
			if  @value | 32768 = @value set @interval=@interval+'四早晨,'
			if  @value | 1048576 = @value set @interval=@interval+'五早晨,'
			if  @value | 33554432 = @value set @interval=@interval+'六早晨,'
			if  @value | 1073741824 = @value set @interval=@interval+'日早晨,'
		end
		if @value | cast(2216757314 as bigint) = @value
			set @interval=@interval+'上午,'
		else
		begin
			if @value | 2 = @value set @interval=@interval+'一上午,'
			if  @value | 64 = @value set @interval=@interval+'二上午,'
			if  @value | 2048 = @value set @interval=@interval+'三上午,'
			if  @value | 65536 = @value set @interval=@interval+'四上午,'
			if  @value | 2097152 = @value set @interval=@interval+'五上午,'
			if  @value | 67108864 = @value set @interval=@interval+'六上午,'
			if  @value | cast(2147483648 as bigint) = @value set @interval=@interval+'日上午,'
		end
			
		if @value | cast(4433514628 as bigint) = @value
			set @interval=@interval+'中午,'
		else
		begin
			if @value | 4 = @value set @interval=@interval+'一中午,'
			if  @value | 128 = @value set @interval=@interval+'二中午,'
			if  @value | 4096 = @value set @interval=@interval+'三中午,'
			if  @value | 131072 = @value set @interval=@interval+'四中午,'
			if  @value | 4194304 = @value set @interval=@interval+'五中午,'
			if  @value | 134217728 = @value set @interval=@interval+'六中午,'
			if  @value | cast(4294967296 as bigint) = @value set @interval=@interval+'日中午,'
		end
		
		if @value | cast(8867029256 as bigint) = @value
			set @interval=@interval+'下午,'
		else
		begin
			if @value | 8 = @value set @interval=@interval+'一下午,'
			if  @value | 256 = @value set @interval=@interval+'二下午,'
			if  @value | 8192 = @value set @interval=@interval+'三下午,'
			if  @value | 262144 = @value set @interval=@interval+'四下午,'
			if  @value | 8388608 = @value set @interval=@interval+'五下午,'
			if  @value | 268435456 = @value set @interval=@interval+'六下午,'
			if  @value | cast(8589934592 as bigint) = @value set @interval=@interval+'日下午,'
		end
		
		if @value | cast(17734058512 as bigint) = @value
			set @interval=@interval+'夜间,'
		else
		begin
			if @value | 16 = @value set @interval=@interval+'一夜间,'
			if  @value | 512 = @value set @interval=@interval+'二夜间,'
			if  @value | 16384 = @value set @interval=@interval+'三夜间,'
			if  @value | 524288 = @value set @interval=@interval+'四夜间,'
			if  @value | 16777216 = @value set @interval=@interval+'五夜间,'
			if  @value | 536870912 = @value set @interval=@interval+'六夜间,'
			if  @value | cast(17179869184 as bigint) = @value set @interval=@interval+'日夜间,'
		end
		return @interval

	end
else
	begin
		RETURN 
		case @type 
			when 'create_type' then 
				case @value 
					when 0 then '报到_自动同步'
					when 1 then '报到_分诊台'
					when 2 then '报到_自助机'
					when 3 then '预约报到_自动同步'
					when 4 then '预约报到_分诊台'
					when 5 then '预约报到_自助机'
					when 6 then '过号_分诊台'
					when 7 then '过号_叫号器'
					when 8 then '过号_自助机'
					when 9 then '复诊_分诊台'
					when 10 then '复诊_自助机'
					when 11 then '已叫重呼_叫号器'
					when 12 then '初诊_分诊台'
					when 13 then '录入'
					when 14 then '挂号_自动同步'
					when 15 then '预约_分诊台'
					else ''
				end
			when 'finish_type' then 
				case @value 
					when 0 then '呼叫'
					when 1 then '诊结'
					when 2 then '过号'
					when 3 then '弃号'
					when 4 then '未报到'
					when 5 then '爽约'
					when 6 then '未呼叫'
					when 7 then '挂起'
					when 8 then '转诊转出'
					when 9 then '退号'
					else ''
				end
			when 'opr_type' then 
				case @value 
					when 2 then '插队'
					when 7 then '分诊'
					when 8 then '挂起'
					when 10 then '缓冲呼叫'
					when 11 then '诊结'
					when 12 then '已过号'
					when 9 then '报到'
					when 3 then '恢复'
					when 13 then '挂起恢复'
					when 14 then '自定义状态'
					when 15 then '分配预留号'
					when 16 then '复诊'
					when 17 then '过号'
					when 18 then '初诊'
					when 20 then '呼叫'
					when 21 then '重呼'
					when 22 then '弃号'
					when 23 then '退号'
					else ''
				end
			when 'opr_type' then 
				case @value 
					when 0 then '初诊'
					when 1 then '预约'
					when 2 then '过号'
					when 3 then '复诊'
					when 4 then '诊室等候'
					when 5 then '插队'
					when 50 then '挂起'
					when -1 then '未报到'
					when 51 then '已呼叫'
					when 8 then '预约未到'
					when 9 then '迟到'
					else ''
				end
			else ''
		end
	end	
return ''
END
go

