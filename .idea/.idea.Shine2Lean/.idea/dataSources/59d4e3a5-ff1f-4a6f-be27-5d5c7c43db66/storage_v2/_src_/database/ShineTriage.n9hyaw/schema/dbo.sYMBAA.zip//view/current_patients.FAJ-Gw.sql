CREATE VIEW [dbo].[current_patients] AS 
SELECT
	cr.id,
	cr.source_id,
	cr.call_time,
	cr.register_id,
	cr.finish_type,
	cr.finish_time,
	s.patient_id,
	s.patient_name,
	d.* 
FROM
	call_record cr
LEFT JOIN traige2queue_type d ON cr.queue_type_id = d.queue_type_id
LEFT JOIN source s ON s.id = cr.source_id
WHERE
	DateDiff(
		dd,
		cr.CREATE_time,
		getdate()
	) < 1
AND (
	cr.finish_type = 0
	OR cr.finish_type = 3
)
OR (
	DATEDIFF(n, cr.finish_time, GETDATE()) < 10
)
UNION
	SELECT
		cr.id,
		cr.source_id,
		cr.call_time,
		cr.register_id,
		cr.finish_type,
		cr.finish_time,
		s.patient_id,
		s.patient_name,
		d.*
	FROM
		call_record cr
	LEFT JOIN traige2queue_type d ON cr.queue_type_id = d.queue_type_id
	LEFT JOIN source s ON s.id = cr.source_id
	WHERE
		DateDiff(
			dd,
			cr.CREATE_time,
			getdate()
		) < 1
	AND (
		cr.finish_type = 0
		OR cr.finish_type = 3
	)
	OR (
		DATEDIFF(n, cr.finish_time, GETDATE()) < 30
	)
	and d.login_id = '2223'
go

