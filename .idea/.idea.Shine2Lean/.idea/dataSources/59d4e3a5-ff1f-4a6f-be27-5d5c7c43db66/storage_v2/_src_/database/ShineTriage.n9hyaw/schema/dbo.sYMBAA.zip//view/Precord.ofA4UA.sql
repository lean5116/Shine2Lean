CREATE VIEW [dbo].[Precord] AS 
SELECT p.id,p.source_id,d.name,s.patient_name,p.call_time,p.register_id,d.login_id,s.patient_id,p.finish_type,p.triage_id
FROM call_record p
LEFT JOIN doctor d on  p.doctor_id=d.id 
LEFT JOIN source s on  s.id=p.source_id
where (p.finish_type=0  or  p.finish_type=3 )
 and DateDiff(dd,p.CREATE_time,getdate())<1
or (DATEDIFF(n, finish_time, GETDATE())<10)
UNION  
SELECT p.id,p.source_id,d.name,s.patient_name,p.call_time,p.register_id,d.login_id,s.patient_id,p.finish_type,p.triage_id
FROM call_record p
LEFT JOIN doctor d on  p.doctor_id=d.id 
LEFT JOIN source s on  s.id=p.source_id
where ((p.finish_type=0  or  p.finish_type=3 )
 and DateDiff(dd,p.CREATE_time,getdate())<1

or (DATEDIFF(n, finish_time, GETDATE())<30))
and  d.login_id = '2223'
go

