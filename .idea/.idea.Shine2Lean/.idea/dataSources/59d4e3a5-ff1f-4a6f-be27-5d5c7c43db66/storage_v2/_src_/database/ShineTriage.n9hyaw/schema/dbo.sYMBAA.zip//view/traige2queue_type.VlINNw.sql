CREATE VIEW [dbo].[traige2queue_type] AS 
select
	tr.id as traige_id,
	tr.ip as traige_ip,
	tr.name as traige_name,
	queue.id as queue_type_id,
	queue.name as queue_type_name,
	queue.source_id as queue_type_source_id,
	doc.login_id 
from  queue_type queue
LEFT JOIN rlt_triage2queue_type tr2queue on queue.id = tr2queue.queue_type_id and queue.is_deleted = '0'

LEFT JOIN triage tr on tr.id = tr2queue.triage_id and tr.is_deleted ='0'

LEFT JOIN rlt_doctor2queue_type doc2queue on doc2queue.queue_type_id = queue.id and doc2queue.is_custom = '0'

LEFT JOIN  doctor doc on doc2queue.doctor_id = doc.id and doc.is_deleted='0' 

where len(doc.login_id)>0
go

