CREATE VIEW [dbo].[v_sstj_hzrc] AS 
SELECT
(
	CASE
WHEN DATEPART (hh, GETDATE()) <= 12 THEN
	(
		SELECT
			COUNT (1)
		FROM
			dbo.call_queue
		WHERE
			triage_id = '4'
		AND time_interval = '2216757314'
	)
ELSE
	(
		SELECT
			COUNT (1)
		FROM
			dbo.call_queue
		WHERE
			triage_id = '4'
		AND time_interval = '8867029256'
	)
END  ) AS '1号楼1楼候诊区/心胸外科、普外科、普外（甲乳）、肛肠外科、神经外科、骨科、骨科（关节、脊柱、创伤）、手足外科、烧伤外科',
(
	CASE
WHEN DATEPART (hh, GETDATE()) <= 12 THEN
	(
		SELECT
			COUNT (1)
		FROM
			dbo.call_queue
		WHERE
			triage_id = '8'
		AND time_interval = '2216757314'
	)
ELSE
	(
		SELECT
			COUNT (1)
		FROM
			dbo.call_queue
		WHERE
			triage_id = '8'
		AND time_interval = '8867029256'
	)
END  ) AS '1号楼2楼候诊区/康复医学科、疼痛科、中医科、老年病科',

(
	CASE
WHEN DATEPART (hh, GETDATE()) <= 12 THEN
	(
		SELECT
			COUNT (1)
		FROM
			dbo.call_queue
		WHERE
			triage_id = '2'
		AND time_interval = '2216757314'
	)
ELSE
	(
		SELECT
			COUNT (1)
		FROM
			dbo.call_queue
		WHERE
			triage_id = '2'
		AND time_interval = '8867029256'
	)
END  )AS '1号楼3楼候诊区/妇科、产科',
(
	CASE
WHEN DATEPART (hh, GETDATE()) <= 12 THEN
	(
		SELECT
			COUNT (1)
		FROM
			dbo.call_queue
		WHERE
			triage_id = '12'
		AND time_interval = '2216757314'
	)
ELSE
	(
		SELECT
			COUNT (1)
		FROM
			dbo.call_queue
		WHERE
			triage_id = '12'
		AND time_interval = '8867029256'
	)
END  ) AS '3号楼1楼候诊区/肝病门诊、内科门诊',
 (
	CASE
WHEN DATEPART (hh, GETDATE()) <= 12 THEN
	(
		SELECT
			COUNT (1)
		FROM
			dbo.call_queue
		WHERE
			triage_id = '7'
		AND time_interval = '2216757314'
	)
ELSE
	(
		SELECT
			COUNT (1)
		FROM
			dbo.call_queue
		WHERE
			triage_id = '7'
		AND time_interval = '8867029256'
	)
END  ) AS '3号楼2楼候诊区/皮肤科、泌尿科',

	(
	CASE
WHEN DATEPART (hh, GETDATE()) <= 12 THEN
	(
		SELECT
			COUNT (1)
		FROM
			dbo.call_queue
		WHERE
			triage_id = '3'
		AND time_interval = '2216757314'
	)
ELSE
	(
		SELECT
			COUNT (1)
		FROM
			dbo.call_queue
		WHERE
			triage_id = '3'
		AND time_interval = '8867029256'
	)
END  
) AS '3号楼3楼候诊区/心血管内科、呼吸内科、戒烟、消化内科、血液肿瘤科、内分泌科、风湿免疫科、神经内科、肾内科、全科医疗科、精神卫生门诊、营养咨询门诊、放射科门诊',
(
	CASE
WHEN DATEPART (hh, GETDATE()) <= 12 THEN
	(
		SELECT
			COUNT (1)
		FROM
			dbo.call_queue
		WHERE
			triage_id = '5'
		AND time_interval = '2216757314'
	)
ELSE
	(
		SELECT
			COUNT (1)
		FROM
			dbo.call_queue
		WHERE
			triage_id = '5'
		AND time_interval = '8867029256'
	)
END  ) AS '3号楼4楼候诊区/儿科、耳鼻喉科',
 --(select COUNT(1)  from shine.shineTriage.dbo.call_queue where triage_id = '6') as '眼科门诊'
(
	CASE
WHEN DATEPART (hh, GETDATE()) <= 12 THEN
	(
		SELECT
			COUNT (1)
		FROM
			dbo.call_queue
		WHERE
			triage_id = '9'
		AND time_interval = '2216757314'
	)
ELSE
	(
		SELECT
			COUNT (1)
		FROM
			dbo.call_queue
		WHERE
			triage_id = '9'
		AND time_interval = '8867029256'
	)
END  ) AS '3号楼5楼候诊区/口腔科'
;
go

